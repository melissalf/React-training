import ProductItem from "./ProductItem";
import classes from "./Products.module.css";
import { useSelector } from "react-redux";

const Products = (props) => {
  const productsData = useSelector((state) => state.product);
  return (
    <section className={classes.products}>
      <h2>Buy your favorite products</h2>
      <ul>
        {productsData.map((item) => {
          return <ProductItem item={item} key={item.id} />;
        })}
      </ul>
    </section>
  );
};

export default Products;
