import classes from "./CartItem.module.css";
import { useDispatch } from "react-redux";
import { cartAction } from "../../store/cart";

const CartItem = ({ item }) => {
  const dispatch = useDispatch();

  // const { title, quantity, total, price } = props.item;
  const total = item.price * item.quantity;

  function handleAdd() {
    dispatch(cartAction.addToCart(item));
  }

  function handleRemove() {
    dispatch(cartAction.removeFromCart(item.id));
  }

  return (
    <li className={classes.item}>
      <header>
        <h3>{item.title}</h3>
        <div className={classes.price}>
          ${total.toFixed(2)}{" "}
          <span className={classes.itemprice}>
            (${item.price.toFixed(2)}/item)
          </span>
        </div>
      </header>
      <div className={classes.details}>
        <div className={classes.quantity}>
          x <span>{item.quantity}</span>
        </div>
        <div className={classes.actions}>
          <button onClick={handleRemove}>-</button>
          <button onClick={handleAdd}>+</button>
        </div>
      </div>
    </li>
  );
};

export default CartItem;
