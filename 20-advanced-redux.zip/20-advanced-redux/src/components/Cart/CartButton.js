import classes from "./CartButton.module.css";
import { useDispatch, useSelector } from "react-redux";
import { uiAction } from "../../store/ui-slice";

const CartButton = (props) => {
  const counter = useSelector((state) => state.cart.totalQuantity);
  const dispatch = useDispatch();

  // const counter = cartItems.items.reduce((value, item) => {
  //   return value + item.quantity;
  // }, 0);

  function handleShowCart() {
    dispatch(uiAction.toggleCart());
  }
  return (
    <button className={classes.button} onClick={handleShowCart}>
      <span>My Cart</span>
      <span className={classes.badge}>{counter}</span>
    </button>
  );
};

export default CartButton;
