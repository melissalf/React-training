import { Fragment, useEffect } from "react";
import Cart from "./components/Cart/Cart";
import Layout from "./components/Layout/Layout";
import Products from "./components/Shop/Products";
import { useSelector, useDispatch } from "react-redux";
// import { uiAction } from "./store/ui-slice";
import Notification from "./components/UI/Notification";
import { sendCartData, fetchCardData } from "./store/cart-actions";

let isInitial = true;

function App() {
  const showCart = useSelector((state) => state.ui.showCart);
  const cart = useSelector((state) => state.cart);
  const notification = useSelector((state) => state.ui.notification);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchCardData());
  }, [dispatch]);

  useEffect(() => {
    // const sentCartData = async () => {
    // dispatch(
    //   uiAction.showNotification({
    //     status: "pending",
    //     title: "Saving in process...",
    //     message: "Sending cart data to database",
    //   })
    // );
    //link from firebase
    // const response = await fetch(
    //   "https://test-react-d28b9-default-rtdb.firebaseio.com/cart.json",
    //   {
    //     method: "PUT",
    //     body: JSON.stringify(cart),
    //   }
    // );
    // if (!response.ok) {
    //   throw new Error("Error while saving the data");
    // }
    // const responseData = await response.json();
    // dispatch(
    //   uiAction.showNotification({ // this is an action creator
    //     status: "success",
    //     title: "Data saved!",
    //     message: "the cart data was save successfully",
    //   })
    // );
    // };

    if (isInitial) {
      isInitial = false;
      return;
    }

    // sentCartData().catch((error) => {
    //   dispatch(
    //     uiAction.showNotification({
    //       status: "error",
    //       title: "Error ocurred!",
    //       message: "Error while saving the data",
    //     })
    //   );
    // });

    if (cart.changed) {
      dispatch(sendCartData(cart));
    }
  }, [cart, dispatch]);

  return (
    <Fragment>
      {notification && <Notification notification={notification} />}
      <Layout>
        {showCart && <Cart />}
        <Products />
      </Layout>
    </Fragment>
  );
}

export default App;
