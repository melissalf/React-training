import { cartAction } from "./cart";
import { uiAction } from "./ui-slice";

export const sendCartData = (cart) => {
  return async (dispatch) => {
    dispatch(
      uiAction.showNotification({
        status: "pending",
        title: "Saving in process...",
        message: "Sending cart data to database",
      })
    );

    const sendRequest = async () => {
      const response = await fetch(
        "https://test-react-d28b9-default-rtdb.firebaseio.com/cart.json",
        {
          method: "PUT",
          body: JSON.stringify({
            items: cart.items,
            totalQuantity: cart.totalQuantity,
            totalAmount: cart.totalAmount,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Error while saving the data");
      }
    };

    try {
      await sendRequest();

      dispatch(
        uiAction.showNotification({
          // this is an action creator
          status: "success",
          title: "Data saved!",
          message: "the cart data was save successfully",
        })
      );
    } catch (error) {
      dispatch(
        uiAction.showNotification({
          status: "error",
          title: "Error ocurred!",
          message: "Error while saving the data",
        })
      );
    }
  };
};

export const fetchCardData = () => {
  return async (dispatch) => {
    const fetchData = async () => {
      const response = await fetch(
        "https://test-react-d28b9-default-rtdb.firebaseio.com/cart.json"
      );

      if (!response.ok) {
        throw new Error("Problem while fetching the data");
      }

      const data = response.json();

      return data;
    };

    try {
      const cartData = await fetchData();
      dispatch(
        cartAction.replaceCart({
          items: cartData.items || [],
          totalQuantity: cartData.totalQuantity,
          totalAmount: cartData.totalAmount,
        })
      );
    } catch (error) {
      dispatch(
        uiAction.showNotification({
          status: "error",
          title: "Error ocurred!",
          message: "Error while fetching the data",
        })
      );
    }
  };
};
