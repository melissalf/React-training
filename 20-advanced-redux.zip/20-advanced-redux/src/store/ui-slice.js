import { createSlice } from "@reduxjs/toolkit";

const initialCart = { showCart: false, notification: null };

const uiSlice = createSlice({
  name: "product",
  initialState: initialCart,
  reducers: {
    toggleCart(state) {
      state.showCart = !state.showCart;
    },
    showNotification(state, action) {
      state.notification = { ...action.payload };
    },
  },
});

export default uiSlice;
export const uiAction = uiSlice.actions;
