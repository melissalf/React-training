import { createSlice } from "@reduxjs/toolkit";

const initialCart = {
  items: [],
  totalAmount: 0,
  totalQuantity: 0,
  changed: false,
};

//   {
//     title: "Test 1",
//     price: 6,
//     quantity: 3,
//   }

const cartSlice = createSlice({
  name: "product",
  initialState: initialCart,
  reducers: {
    addToCart(state, action) {
      const itemIndex = state.items.findIndex(
        (item) => item.id === action.payload.id
      );
      if (itemIndex > -1) {
        state.items[itemIndex].quantity += 1;
      } else {
        state.items.push({ ...action.payload, quantity: 1 });
      }

      state.totalQuantity++;
      state.totalAmount += action.payload.price;
      state.changed = true;
    },
    removeFromCart(state, action) {
      const itemIndex = state.items.findIndex(
        (item) => item.id === action.payload
      );

      state.totalAmount -= state.items[itemIndex].price;

      if (state.items[itemIndex].quantity > 1) {
        state.items[itemIndex].quantity -= 1;
      } else {
        state.items = state.items.filter((item) => item.id !== action.payload);
      }
      state.totalQuantity--;
      state.changed = true;
    },
    replaceCart(state, action) {
      state.totalQuantity = action.payload.totalQuantity;
      state.items = action.payload.items;
      state.totalAmount = action.payload.totalAmount;
    },
  },
});

export default cartSlice.reducer;
export const cartAction = cartSlice.actions;
