import { createSlice } from "@reduxjs/toolkit";

const initialProducts = [
  {
    id: "p1",
    title: "Test 1",
    price: 6,
    description: "This is a first product Test - amazing!",
  },
  {
    id: "p2",
    title: "Test 2",
    price: 10,
    description: "This is Another one!",
  },
  {
    id: "p3",
    title: "Something",
    price: 7,
    description: "Product just for giggles!",
  },
];

const productSlice = createSlice({
  name: "product",
  initialState: initialProducts,
  reducers: {
    test() {
      console.log("this is a test");
    },
  },
});

export default productSlice.reducer;
export const productAction = productSlice.actions;
