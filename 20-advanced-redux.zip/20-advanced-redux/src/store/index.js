import { configureStore } from "@reduxjs/toolkit";
import productReducer from "./product";
import cartReducer from "./cart";
import uiSlice from "./ui-slice";

const mainStore = configureStore({
  reducer: { product: productReducer, cart: cartReducer, ui: uiSlice.reducer },
});

export default mainStore;
