import Cart from "./components/Cart.jsx";
import Checkout from "./components/Checkout.jsx";
import Header from "./components/Header";
import Menu from "./components/Menu";
import CartContextProvider from "./store/CartContext.jsx";
import ModalContextProvider from "./store/modalContext.jsx";

function App() {
  return (
    <CartContextProvider>
      <ModalContextProvider>
        <Cart />
        <Checkout />
        <Header />
        <Menu />
      </ModalContextProvider>
    </CartContextProvider>
  );
}

export default App;
