import { useCallback, useEffect, useState } from "react";

async function sentHttpsRequest(url, config) {
  const response = await fetch(url, config);

  const resData = await response.json();

  if (!response.ok) {
    throw new Error(resData || "Failed to sent order");
  }

  return resData;
}

export default function useHttp(url, config, initialData) {
  const [requestError, setRequestError] = useState();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(initialData);

  function clearData() {
    setSuccess(initialData);
  }

  const sendRequest = useCallback(
    async function sendRequest(data) {
      setLoading(true);
      try {
        const response = await sentHttpsRequest(url, { ...config, body: data });
        setSuccess(response);
      } catch (error) {
        setRequestError(error.message || "Failed to sent order");
      }
      setLoading(false);
    },
    [url, config]
  );

  useEffect(() => {
    if ((config && (config.method === "GET" || !config.method)) || !config) {
      sendRequest();
    }
  }, [sendRequest]);

  return {
    success,
    loading,
    requestError,
    sendRequest,
    clearData,
  };
}
