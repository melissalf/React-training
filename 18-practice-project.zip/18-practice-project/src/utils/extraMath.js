export function totalCount(meals) {
  const totalOrder = meals.reduce((value, item) => {
    return value + item.counter;
  }, 0);
  return totalOrder;
}

export function countTotalPrice(meals) {
  const totalPrice = meals.reduce((value, item) => {
    return value + item.counter * item.price;
  }, 0);
  return totalPrice;
}
