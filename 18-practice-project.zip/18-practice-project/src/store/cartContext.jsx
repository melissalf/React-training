import { createContext, useState } from "react";

const defaultCartData = [];

export const CartContext = createContext({
  selectedMeals: defaultCartData,
  addMeal: () => {},
  removeMeal: () => {},
  cleanCart: () => {},
});

export default function CartContextProvider({ children }) {
  const [selectedMeals, setSelectedMeals] = useState(defaultCartData);

  function handleAddMeal(meal) {
    setSelectedMeals((prevMeals) => {
      const existingPick = prevMeals.findIndex((food) => food.id === meal.id);
      const updateMeals = [...prevMeals];
      console.log(existingPick);
      if (existingPick > -1) {
        const updateMeal = {
          ...prevMeals[existingPick],
          counter: prevMeals[existingPick].counter + 1,
        };
        updateMeals[existingPick] = updateMeal;
      } else {
        updateMeals.push({ ...meal, counter: 1 });
      }
      // updateMeals = [...prevMeals, meal]
      return updateMeals;
    });
  }

  function handleRemoveMeal(meal) {
    setSelectedMeals((prevMeals) => {
      let updateMeals = [...prevMeals];
      const existingPick = prevMeals.findIndex((food) => food.id === meal.id);
      if (existingPick > -1 && prevMeals[existingPick].counter > 1) {
        const updateMeal = {
          ...prevMeals[existingPick],
          counter: prevMeals[existingPick].counter - 1,
        };
        updateMeals[existingPick] = updateMeal;
      } else {
        updateMeals = prevMeals.filter((food) => food.id !== meal.id);
        // updateMeals.splice(existingPick, 1);
      }

      return updateMeals;
    });
  }

  function clearCart() {
    setSelectedMeals(defaultCartData);
  }

  const cartCtx = {
    selectedMeals,
    addMeal: handleAddMeal,
    removeMeal: handleRemoveMeal,
    cleanCart: clearCart,
  };
  console.log(selectedMeals);

  return (
    <CartContext.Provider value={cartCtx}>{children}</CartContext.Provider>
  );
}
