import { createContext, useState } from "react";

export const ModalContext = createContext({
  modalState: "",
  openModal: () => {},
  closeModal: () => {},
});

export default function ModalContextProvider({ children }) {
  const [modalState, setModalState] = useState("");

  function handleOpenClick(place) {
    setModalState(place);
  }

  function handleCloseClick() {
    setModalState("");
  }

  const modalCtx = {
    modalState,
    openModal: handleOpenClick,
    closeModal: handleCloseClick,
  };
  return (
    <ModalContext.Provider value={modalCtx}>{children}</ModalContext.Provider>
  );
}
