// import { useEffect, useState } from "react";
// import { getAvailableMeals } from "../utils/https.js";
import Food from "./Food.jsx";
import useHttp from "../hooks/useHttp.js";
import Error from "./Error.jsx";

const requestConfig = {};

function Menu() {
  const {
    success: meals,
    loading,
    requestError,
  } = useHttp("http://localhost:3000/meals", requestConfig, []);

  if (requestError) {
    return <Error title="An error ocurred" message={requestError} />;
  }

  // const [loading, setLoading] = useState(false);
  // const [meals, setMeals] = useState([]);
  // const [hasError, setHasError] = useState();

  // useEffect(() => {
  //   setLoading(true);
  //   async function fetchFoodOptions() {
  //     try {
  //       const options = await getAvailableMeals();
  //       setMeals(options);
  //     } catch (error) {
  //       setHasError({
  //         message:
  //           error.message || "Error while trying to get the available meals",
  //       });
  //     }
  //     setLoading(false);
  //   }

  //   fetchFoodOptions();
  // }, []);

  //console.log(meals);

  return (
    <ul id="meals">
      {loading && <p className="center">Getting food options</p>}
      {!loading &&
        meals.map((meal) => {
          return <Food foodData={meal} key={meal.id} />;
        })}
    </ul>
  );
}

export default Menu;
