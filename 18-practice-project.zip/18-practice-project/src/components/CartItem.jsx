import { useContext } from "react";
import { CartContext } from "../store/CartContext";
import { currencyFormatter } from "../utils/formatting.js";

function CartItem({ item }) {
  const { addMeal, removeMeal } = useContext(CartContext);
  return (
    <li className="cart-item">
      <p>
        {item.name} - {item.counter} x {currencyFormatter.format(item.price)}
      </p>
      <p className="cart-item-actions">
        <button
          onClick={() => {
            removeMeal(item);
          }}
        >
          -
        </button>
        {item.counter}
        <button
          onClick={() => {
            addMeal(item);
          }}
        >
          +
        </button>
      </p>
    </li>
  );
}

export default CartItem;
