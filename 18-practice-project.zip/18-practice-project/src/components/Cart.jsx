import { useContext } from "react";
import { CartContext } from "../store/CartContext";
import Modal from "./Modal.jsx";
import { currencyFormatter } from "../utils/formatting.js";
import { ModalContext } from "../store/modalContext.jsx";
import Button from "./UI/Button.jsx";
import CartItem from "./CartItem.jsx";
import { totalCount, countTotalPrice } from "../utils/extraMath.js";

function Cart() {
  const { modalState, closeModal, openModal } = useContext(ModalContext);
  const { selectedMeals } = useContext(CartContext);
  const totalPrice = countTotalPrice(selectedMeals);

  const totalOrder = totalCount(selectedMeals);

  function handlePayOrder() {
    console.log("Paying order");
    openModal("checkout");
  }

  return (
    <Modal
      open={modalState === "cart"}
      className="cart"
      onClose={modalState === "cart" ? closeModal : null}
    >
      <h2>Your selected Meals</h2>
      <ul>
        {selectedMeals.map((item) => {
          return <CartItem item={item} key={item.id} />;
        })}
      </ul>
      <p className="cart-total">
        Price: {currencyFormatter.format(totalPrice)}
      </p>
      <p className="modal-actions">
        <Button onClick={closeModal} textOnly>
          Close
        </Button>
        {totalOrder > 0 && (
          <Button onClick={handlePayOrder}>Checkout and Pay</Button>
        )}
      </p>
    </Modal>
  );
}

export default Cart;
