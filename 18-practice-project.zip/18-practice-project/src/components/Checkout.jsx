import Modal from "./Modal";
import { ModalContext } from "../store/modalContext.jsx";
import { CartContext } from "../store/cartContext.jsx";
import { useContext } from "react";
import { countTotalPrice } from "../utils/extraMath.js";
import { currencyFormatter } from "../utils/formatting.js";
import Input from "./Input.jsx";
import Button from "./UI/Button.jsx";
import useHttp from "../hooks/useHttp.js";
import Error from "./Error.jsx";

const requestedConfig = {
  method: "POST",
  headers: {
    "Content-type": "application/json",
  },
};

function Checkout() {
  const { modalState, closeModal } = useContext(ModalContext);
  const { selectedMeals, cleanCart } = useContext(CartContext);
  const totalPrice = currencyFormatter.format(countTotalPrice(selectedMeals));

  const { success, loading, requestError, sendRequest, clearData } = useHttp(
    "http://localhost:3000/orders",
    requestedConfig
  );

  function handleSubmit(event) {
    event.preventDefault();

    console.log("----submit order---");
    const formResults = new FormData(event.target);
    const userData = Object.fromEntries(formResults.entries());
    console.log(userData);

    sendRequest(
      JSON.stringify({
        order: {
          customer: userData,
          items: selectedMeals,
        },
      })
    );

    // fetch("http://localhost:3000/orders", {
    //   method: "POST",
    //   headers: {
    //     "Content-type": "application/json",
    //   },
    //   body: JSON.stringify({
    //     order: {
    //       customer: userData,
    //       items: selectedMeals,
    //     },
    //   }),
    // });
  }

  function handleFinish() {
    closeModal();
    cleanCart();
    clearData();
  }

  let actions = (
    <>
      <Button onClick={closeModal} type="button" textOnly>
        Close
      </Button>
      <Button>Submit Order</Button>
    </>
  );

  if (loading) {
    actions = <span>Sending order data...</span>;
  }

  if (success && !requestError) {
    return (
      <Modal open={modalState === "checkout"} onClose={closeModal}>
        <h2>Success!</h2>
        <p>Your order have been received!</p>
        <p>You will receive an email with more details in a few minutes</p>
        <p className="modal-actions">
          <Button onClick={handleFinish}>Okay</Button>
        </p>
      </Modal>
    );
  }
  // console.log(requestError);

  return (
    <Modal open={modalState === "checkout"} onClose={closeModal}>
      <form onSubmit={handleSubmit}>
        <h2>Checkout:</h2>
        <p>Total amount: {totalPrice}</p>
        <Input label="Full Name" type="text" id="name" />
        <Input label="E-mail" type="email" id="email" />
        <Input label="Street" type="text" id="street" />
        <div className="control-row">
          <Input label="Postal code" type="text" id="postal-code" />
          <Input label="City" type="text" id="city" />
        </div>
        {requestError && (
          <Error title="Error sending Order" message={requestError} />
        )}
        <p className="modal-actions">{actions}</p>
      </form>
    </Modal>
  );
}

export default Checkout;
