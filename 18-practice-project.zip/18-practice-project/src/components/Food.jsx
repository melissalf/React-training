import { useContext } from "react";
import { currencyFormatter } from "../utils/formatting.js";
import { CartContext } from "../store/CartContext.jsx";
import Button from "./UI/Button.jsx";

function Food({ foodData }) {
  // console.log("---meal---", foodData);
  const { addMeal } = useContext(CartContext);

  function handleSelectedMeal() {
    console.log("---Click button----");
    addMeal(foodData);
  }

  return (
    <li className="meal-item">
      <article>
        <img
          src={`http://localhost:3000/${foodData.image}`}
          alt={foodData.name}
        />
        <div>
          <h3>{foodData.name}</h3>
          <p className="meal-item-price">
            {currencyFormatter.format(foodData.price)}
          </p>
          <p className="meal-item-description">{foodData.description}</p>
        </div>
        <p className="meal-item-actions">
          <Button onClick={handleSelectedMeal}>Add to cart</Button>
        </p>
      </article>
    </li>
  );
}

export default Food;
