import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";

function Modal({ children, open, onClose, className = "" }) {
  const modalRef = useRef();
  useEffect(() => {
    const stateModal = modalRef.current;
    if (open) {
      stateModal.showModal();
    }
    // else {
    //   stateModal.close();
    // }

    return () => stateModal.close();
  }, [open]);

  const modalClass = `modal ${className}`;

  return createPortal(
    <dialog ref={modalRef} className={modalClass} onClose={onClose}>
      {children}
    </dialog>,
    document.getElementById("modal")
  );
}

export default Modal;
