import logoImg from "../assets/logo.jpg";
import Button from "./UI/Button.jsx";
import { useContext } from "react";
import { CartContext } from "../store/CartContext";
import { ModalContext } from "../store/modalContext.jsx";
import { totalCount } from "../utils/extraMath.js";

function Header() {
  const { selectedMeals } = useContext(CartContext);
  const { openModal } = useContext(ModalContext);
  const totalOrder = totalCount(selectedMeals);

  function handleOpenCart() {
    openModal("cart");
  }

  return (
    <>
      <header id="main-header">
        <div id="title">
          <img src={logoImg} alt="Restaurant logo" />
          <h1>React food order</h1>
        </div>
        <nav>
          <Button onClick={handleOpenCart} textOnly>
            <p>Cart ({totalOrder})</p>
          </Button>
        </nav>
      </header>
    </>
  );
}

export default Header;
