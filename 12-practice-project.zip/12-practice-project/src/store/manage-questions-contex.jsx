import { createContext, useState } from "react";
import QUESTIONS from "../../questions.js";

// answersInfo have: answer, question, id, type (correct, incorrect, skip)
const defaultAnswerContext = {
  answersInfo: [],
  onAddAnswer: () => {},
};

export const AnswersContext = createContext(defaultAnswerContext);

export default function AnswerContextProvider({ children }) {
  const [answersStatus, setAnswersStatus] = useState(defaultAnswerContext);

  // answer is an object
  function handleAddAnswer(answer) {
    setAnswersStatus((prevAnswerStatus) => {
      return {
        ...prevAnswerStatus,
        answersInfo: [...prevAnswerStatus.answersInfo, answer],
      };
    });
  }
  const answerCtx = {
    ...answersStatus,
    onAddAnswer: handleAddAnswer,
  };

  // console.log(answersStatus);
  return (
    <AnswersContext.Provider value={answerCtx}>
      {children}
    </AnswersContext.Provider>
  );
}
