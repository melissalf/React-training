import { useEffect, useState } from "react";

function ProgressBar({ timer, currentInterval, mode }) {
  const [intervalTime, setIntervalTime] = useState(timer);

  useEffect(() => {
    const interval = setInterval(() => {
      setIntervalTime((prevTime) => {
        return prevTime - 100;
      });
    }, 100);

    return () => {
      clearInterval(interval);
      // setIntervalTime(timer);
    };
  }, [currentInterval]);

  return (
    <progress
      id="question-time"
      value={intervalTime}
      max={timer}
      className={mode}
    />
  );
}

export default ProgressBar;
