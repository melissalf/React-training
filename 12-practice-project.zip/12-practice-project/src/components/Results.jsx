import { useContext } from "react";
import resultImg from "../assets/quiz-complete.png";
import { AnswersContext } from "../store/manage-questions-contex.jsx";
import ResultAnswer from "./ResultAnswer";

function getPercent(partial, total) {
  return Math.round((100 * partial) / total);
}

function Result() {
  const { answersInfo } = useContext(AnswersContext);

  //save in local storage
  // localStorage.setItem("answersResult", JSON.stringify(answersInfo));

  const correct = getPercent(
    answersInfo.filter((element) => element.type === "correct").length,
    answersInfo.length
  );
  const wrong = getPercent(
    answersInfo.filter((element) => element.type === "wrong").length,
    answersInfo.length
  );
  const skip = getPercent(
    answersInfo.filter((element) => element.type === "skipped").length,
    answersInfo.length
  );

  return (
    <div id="summary">
      <img src={resultImg} alt="complete quiz image" />
      <h2>Quiz completed!</h2>
      <div id="summary-stats">
        <p>
          <span className="number">{skip}%</span>
          <span className="text">Skipped</span>
        </p>
        <p>
          <span className="number">{correct}%</span>
          <span className="text">Answered correctly</span>
        </p>
        <p>
          <span className="number">{wrong}%</span>
          <span className="text">Answered incorrectly</span>
        </p>
      </div>
      <ol>
        {answersInfo.map((element, i) => {
          return (
            <ResultAnswer
              key={i}
              answer={element.answer}
              question={element.question}
              type={element.type}
              n={i}
            />
          );
        })}
      </ol>
    </div>
  );
}

export default Result;
