function ResultAnswer({ question, answer, type, n }) {
  const answerClasses = `user-answer ${type}`;
  const answerOutput = answer === "" ? " Answer skipped" : answer;
  return (
    <li>
      <h3>{n + 1}</h3>
      <p className="question">{question}</p>
      <p className={answerClasses}>{answerOutput}</p>
    </li>
  );
}

export default ResultAnswer;
