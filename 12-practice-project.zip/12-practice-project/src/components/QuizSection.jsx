import { useContext, useState, useEffect, useRef } from "react";
import QUESTIONS from "../../questions.js";
import ProgressBar from "./ProgressBar.jsx";
import { AnswersContext } from "../store/manage-questions-contex.jsx";
import Answers from "./Answers.jsx";

const TIMER = 10000;

function defineType(answer, correctAnswer) {
  let type;
  if (answer === correctAnswer) {
    type = "correct";
  } else if (answer === "") {
    type = "skipped";
  } else {
    type = "wrong";
  }
  return type;
}

function QuizSection({ onFinish }) {
  const [currentQuestion, setCurrentQuestion] = useState(QUESTIONS[0]);
  const { onAddAnswer, answersInfo } = useContext(AnswersContext);
  const [answerState, setAnswerState] = useState("");
  const timer = useRef(TIMER);

  const correctAnswer = currentQuestion.answers[0];

  useEffect(() => {
    console.log("----set timeout");
    const timerVar = setTimeout(() => {
      if (answerState === "") {
        console.log("----END timeout");
        handleClickQuestion("");
      }
    }, TIMER);

    return () => {
      console.log("----Clear timeout");
      clearTimeout(timerVar);
    };
  }, [currentQuestion]);

  function handleClickQuestion(answer) {
    const type = defineType(answer, correctAnswer);
    const thisAnswer = {
      answer,
      question: currentQuestion.text,
      id: currentQuestion.id,
      type,
    };

    if (answer === "") {
      onAddAnswer(thisAnswer);
      if (currentQuestion.id === QUESTIONS[QUESTIONS.length - 1].id) {
        onFinish(true);
        return;
      } else {
        setAnswerState("");
        setCurrentQuestion(QUESTIONS[answersInfo.length + 1]);
      }
      timer.current = TIMER;
    } else {
      setAnswerState(answer);
      timer.current = 1000;
      setTimeout(() => {
        setAnswerState(type);
        timer.current = 2000;

        setTimeout(() => {
          onAddAnswer(thisAnswer);
          if (currentQuestion.id === QUESTIONS[QUESTIONS.length - 1].id) {
            onFinish(true);
            return;
          } else {
            setAnswerState("");
            setCurrentQuestion(QUESTIONS[answersInfo.length + 1]);
          }
          timer.current = TIMER;
        }, 2000);
      }, 1000);
    }
  }
  // <Question timer={TIMER} currentQuestion={currentQuestion} handleClickQuestion={handleClickQuestion} lengthIndex={answersInfo.length} />
  return (
    <section id="quiz">
      <div id="question">
        <ProgressBar
          timer={timer.current}
          currentInterval={currentQuestion}
          key={`bar-${answersInfo.length}${answerState}`}
          mode={answerState}
        />
        <h2>{currentQuestion.text}</h2>
        <Answers
          key={answersInfo.length}
          answers={currentQuestion.answers}
          answerState={answerState}
          onSelect={handleClickQuestion}
        />
      </div>
    </section>
  );
}

export default QuizSection;
