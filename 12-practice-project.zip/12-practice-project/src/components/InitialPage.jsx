function InitialPage() {
  return <h1>Initial Page</h1>;
}

export default InitialPage;
