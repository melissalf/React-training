import Answers from "./Answers.jsx";
import ProgressBar from "./ProgressBar.jsx";

function Question({
  timer,
  currentQuestion,
  lengthIndex,
  handleClickQuestion,
}) {
  return (
    <div id="question">
      <ProgressBar
        timer={timer}
        currentInterval={currentQuestion}
        key={lengthIndex}
      />
      <h2>{currentQuestion.text}</h2>
      <Answers
        key={lengthIndex}
        answers={currentQuestion.answers}
        answerState={answerState}
        onSelect={handleClickQuestion}
      />
    </div>
  );
}

export default Question;
