import { useRef } from "react";

function Answers({ answers, selectedAnswer, answerState, onSelect }) {
  const shuffleAnswers = useRef();

  if (!shuffleAnswers.current) {
    shuffleAnswers.current = [...answers];
    shuffleAnswers.current.sort(() => Math.random() - 0.5);
  }
  return (
    <ul id="answers">
      {shuffleAnswers.current.map((element, i) => {
        let cssClass = "";

        if (element === answerState) {
          cssClass = "selected";
        } else if (answerState === "correct" || answerState === "wrong") {
          cssClass = answerState;
        }
        return (
          <li key={i} className="answer">
            <button onClick={() => onSelect(element)} className={cssClass}>
              {element}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

export default Answers;
