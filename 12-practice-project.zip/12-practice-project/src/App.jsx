import { useState } from "react";
import Header from "./components/Header";
import QuizSection from "./components/QuizSection";
import Result from "./components/Results";
import AnswerContextProvider from "./store/manage-questions-contex";

function App() {
  const [finishedQuiz, setFinishedQuiz] = useState(false);

  let content = <QuizSection onFinish={setFinishedQuiz} />;
  if (finishedQuiz) {
    content = <Result />;
  }
  return (
    <AnswerContextProvider>
      <Header />
      {content}
    </AnswerContextProvider>
  );
}

export default App;
