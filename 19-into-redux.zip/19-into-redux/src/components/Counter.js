// import { Component } from "react";
// import { useSelector, useDispatch, connect } from "react-redux";
import classes from "./Counter.module.css";
//allow to select a part of the states that the store manages
import { useSelector, useDispatch } from "react-redux";
// import { PLUS, PLUS_BY_N, MINOR } from "../store/index";
import { counterActions } from "../store/counter";

const Counter = () => {
  // subscription example
  // const counter = useSelector((state) => state.counter.counter);
  // const showCounter = useSelector((state) => state.counter.showCounter);
  const counterSubscription = useSelector((state) => state.counter);

  //dispach action example
  const dispatch = useDispatch();

  function incrementHandler() {
    //forma con el redux estandar
    // dispatch({ type: PLUS });
    dispatch(counterActions.plus());
  }

  const decrementHandler = () => {
    dispatch(counterActions.minor());
  };

  function incrementNHandler() {
    dispatch(counterActions.plusByN(5));
  }

  const toggleCounterHandler = () => {
    dispatch(counterActions.toggle());
  };

  return (
    <main className={classes.counter}>
      <h1>Redux Counter</h1>
      {counterSubscription.showCounter && (
        <div className={classes.value}> {counterSubscription.counter} </div>
      )}
      <div>
        <button onClick={decrementHandler}>Decrement</button>
        <button onClick={incrementHandler}>Increment</button>
        <button onClick={incrementNHandler}>Increment by 5</button>
      </div>
      <button onClick={toggleCounterHandler}>Toggle Counter</button>
    </main>
  );
};

// Same example with class
// class Counter extends Component {
//   incrementHandler() {
//     this.props.increment();
//   }

//   decrementHandler() {
//     this.props.decrement();
//   }

//   toggleCounterHandler() {}

//   render() {
//     return (
//       <main className={classes.counter}>
//         <h1>Redux Counter</h1>
//         <div className={classes.value}>-- {this.props.counter} --</div>
//         <div>
//           <button onClick={this.decrementHandler.bind(this)}>Decrement</button>
//           <button onClick={this.incrementHandler.bind(this)}>Increment</button>
//         </div>
//         <button onClick={this.toggleCounterHandler}>Toggle Counter</button>
//       </main>
//     );
//   }
// }

// // this is an alternative to useSelector and useDispatch
// const mapStateToProps = (state) => {
//   return {
//     counter: state.counter,
//   };
// };

// const mapDispatchToProps = (dispatch) => {
//   return {
//     increment: () => dispatch({ type: "plus" }),
//     decrement: () => dispatch({ type: "minor" }),
//   };
// };

export default Counter;
// export default connect(mapStateToProps, mapDispatchToProps)(Counter);
