import classes from "./Header.module.css";
import { useSelector, useDispatch } from "react-redux";
import { profileActions } from "../store/profile";

const Header = () => {
  const profileSubscription = useSelector((state) => state.profile);
  const dispatch = useDispatch();

  function handleLogOut() {
    dispatch(profileActions.logOut());
  }

  let menu = (
    <ul>
      <li>
        <a href="/">My Products</a>
      </li>
      <li>
        <a href="/">My Sales</a>
      </li>
      <li>
        <button onClick={handleLogOut}>Logout</button>
      </li>
    </ul>
  );
  return (
    <header className={classes.header}>
      <h1>Redux Auth</h1>
      <nav>{profileSubscription.isAuthenticated && menu}</nav>
    </header>
  );
};

export default Header;
