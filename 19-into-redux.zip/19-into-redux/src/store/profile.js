import { createSlice } from "@reduxjs/toolkit";

const initialProfileState = {
  isAuthenticated: false,
};

const profileSlice = createSlice({
  name: "profile",
  initialState: initialProfileState,
  reducers: {
    logIn(state) {
      state.isAuthenticated = true;
    },
    logOut(state) {
      state.isAuthenticated = false;
    },
  },
});

export default profileSlice.reducer;
export const profileActions = profileSlice.actions;
