// import { createStore } from "redux";
import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./counter";
import profileReducer from "./profile";

//constantes
// export const PLUS = "plus";
// export const MINOR = "minor";
// export const PLUS_BY_N = "plusByN";

// const counterReducer = (state = initialState, action) => {
//   if (action.type === PLUS) {
//     return {
//       ...state,
//       counter: state.counter + 1,
//     };
//   }
//   if (action.type === MINOR) {
//     return {
//       ...state,
//       counter: state.counter - 1,
//     };
//   }

//   if (action.type === PLUS_BY_N) {
//     return {
//       ...state,
//       counter: state.counter + action.intInput,
//     };
//   }

//   if (action.type === "toggle") {
//     return {
//       ...state,
//       showCounter: !state.showCounter,
//     };
//   }

//   return state;
// };

// const counterStore = createStore(counterReducer);

// const counterSubscription = () => {
//     const lastState = counterReducer.getState()
//     console.log(lastState);
// }

// ejemplo de ejecutar actions
// counterSlice.actions.toggle()

const counterStore = configureStore({
  reducer: { counter: counterReducer, profile: profileReducer },
});

export default counterStore;
