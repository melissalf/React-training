import { useRef, useState } from "react";

const DEFAULT_USER = {
  email: "",
  password: "",
};

export default function Login() {
  const userInput = useRef(DEFAULT_USER);
  const [emailIsInvalid, setEmailIsInvalid] = useState(false);

  function handleSubmit(event) {
    //avoid the default http request on submit
    event.preventDefault();
    console.log("-----submit-----");
    console.log(userInput.current.email.value);
    console.log(userInput.current.password.value);

    const emailInvalid = !userInput.current.email.value.includes("@");
    if (emailInvalid) {
      setEmailIsInvalid(emailInvalid);
      return;
    } else {
      setEmailIsInvalid(emailInvalid);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>

      <div className="control-row">
        <div className="control no-margin">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            name="email"
            ref={(ref) => (userInput.current.email = ref)}
          />
          <div className="control-error">
            {emailIsInvalid && <p>Valid email address must have @ symbol</p>}
          </div>
        </div>

        <div className="control no-margin">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            name="password"
            ref={(ref) => (userInput.current.password = ref)}
          />
        </div>
      </div>

      <p className="form-actions">
        <button className="button button-flat">Reset</button>
        <button className="button">Login</button>
      </p>
    </form>
  );
}
