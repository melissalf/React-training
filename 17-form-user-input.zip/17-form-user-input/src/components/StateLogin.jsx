import { useState } from "react";
import Input from "./Input.jsx";
import { isEmail, isNotEmpty, hasMinLength } from "../util/validation.js";
import { useInput } from "../hooks/useInput.js";

export default function StateLogin() {
  const {
    value: emailValue,
    hasError: emailError,
    handleBlur: handleEmailBlur,
    handleChange: handleEmailChange,
  } = useInput("", (value) => {
    return isEmail(value) && isNotEmpty(value);
  });
  const {
    value: passValue,
    hasError: passError,
    handleBlur: handlePassBlur,
    handleChange: handlePassChange,
  } = useInput("", (value) => {
    return hasMinLength(value, 7);
  });
  // const [userForm, setUserForm] = useState({
  //   email: "",
  //   password: "",
  // });

  // const [editForm, setEditForm] = useState({
  //   email: false,
  //   password: false,
  // });

  function handleSubmit(event) {
    //avoid the default http request on submit
    event.preventDefault();
    if (emailError || passError) {
      return;
    }
    console.log("-----submit-----");
    console.log(emailValue, passValue);
  }

  // function handleChange(event) {
  //   setUserForm((prevUserForm) => {
  //     return {
  //       ...prevUserForm,
  //       [event.target.name]: event.target.value,
  //     };
  //   });
  //   setEditForm((prevEditForm) => {
  //     return {
  //       ...prevEditForm,
  //       [event.target.name]: false,
  //     };
  //   });
  // }

  // // this executes when the input lost focus
  // function handleBlur(event) {
  //   setEditForm((prevEditForm) => {
  //     return {
  //       ...prevEditForm,
  //       [event.target.name]: true,
  //     };
  //   });
  // }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>

      <div className="control-row">
        <Input
          labelName="Email"
          idName="email"
          error={emailError && "Valid email address must have @ symbol"}
          type="email"
          onBlur={handleEmailBlur}
          onChange={handleEmailChange}
          value={emailValue}
        />

        <Input
          labelName="Password"
          idName="password"
          type="password"
          error={passError && "Password must be 7 characters long"}
          onBlur={handlePassBlur}
          onChange={handlePassChange}
          value={passValue}
        />
      </div>

      <p className="form-actions">
        <button className="button button-flat">Reset</button>
        <button className="button">Login</button>
      </p>
    </form>
  );
}
