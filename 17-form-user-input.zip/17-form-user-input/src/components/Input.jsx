export default function Input({ labelName, idName, error, ...props }) {
  return (
    <div className="control no-margin">
      <label htmlFor={idName}>{labelName}</label>
      <input id={idName} name={idName} {...props} />
      <div className="control-error">{error && <p>{error}</p>}</div>
    </div>
  );
}
