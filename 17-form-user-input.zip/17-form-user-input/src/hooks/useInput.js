import { useState } from "react";

export function useInput(defaultValue, validationFn) {
  const [userForm, setUserForm] = useState(defaultValue);
  const [editForm, setEditForm] = useState(false);

  const valueIsValid = validationFn(userForm);

  function handleChange(event) {
    setUserForm(event.target.value);
    setEditForm(false);
  }

  // this executes when the input lost focus
  function handleBlur() {
    setEditForm(true);
  }

  return {
    value: userForm,
    hasError: editForm && !valueIsValid,
    handleBlur,
    handleChange,
  };
}
