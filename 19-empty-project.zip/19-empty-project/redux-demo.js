const redux = require("redux");

// reducer function
const counterReducer = (state = { counter: 0 }, action) => {
  if (action.type === "increment") {
    return {
      counter: state.counter + 1,
    };
  }

  if (action.type === "decrement") {
    return {
      counter: state.counter - 1,
    };
  }

  return state;
};

//how to create a store
const storeExample = redux.createStore(counterReducer);

// console.log(storeExample.getState());

//suscription
const counterSubscriber = () => {
  const lastState = storeExample.getState();
  console.log(lastState);
};

storeExample.subscribe(counterSubscriber);

//action that can be dispatch

storeExample.dispatch({
  type: "increment",
});

storeExample.dispatch({
  type: "decrement",
});
