export default function Shop({ children }) {
  // first solution for the prop drilling: Component composition
  // the data here was pass to App to get rid of one layer of component nesting
  return (
    <section id="shop">
      <h2>Elegant Clothing For Everyone</h2>

      <ul id="products">{children}</ul>
    </section>
  );
}
