import MainNavBar from "../components/MainNavBar";

export default function ErrorPage() {
  return (
    <>
      <MainNavBar />
      <main>
        <h1>Page not found!</h1>
        <p>The page you are trying to access couldn't be reached</p>
      </main>
    </>
  );
}
