import PageContent from "../components/PageContent";

function HomePage() {
  return (
    <PageContent title="The home page">
      <p> Description here</p>
    </PageContent>
  );
}

export default HomePage;
