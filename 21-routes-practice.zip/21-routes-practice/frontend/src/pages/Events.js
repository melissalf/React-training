// import { useEffect, useState } from "react";
import { Suspense } from "react";
import EventsList from "../components/EventsList";
import { defer, json, useLoaderData, Await } from "react-router-dom";

function EventPage() {
  // const [eventData, setEventData] = useState();
  // const [error, setError] = useState();
  // const [isLoading, setIsLoading] = useState(false);

  // useEffect(() => {
  //   const getEventsData = async () => {
  //     setIsLoading(true);

  //     setIsLoading(false);
  //   };

  //   getEventsData();
  // }, []);
  const data = useLoaderData();

  //first change
  // if (data.isError) {
  //   return <p>{data.message}</p>;
  // }

  //second change
  // const eventData = data.events;

  // return (
  //   <>
  //     <EventsList events={eventData} />
  //   </>
  // );

  return (
    <Suspense fallback={<p style={{ textAlign: "center" }}>Loading...</p>}>
      <Await resolve={data.events}>
        {(loadedEvents) => {
          return <EventsList events={loadedEvents} />;
        }}
      </Await>
    </Suspense>
  );
}

async function loadEvents() {
  // fetch returns a response that is a feature from the browser
  const response = await fetch("http://localhost:8080/events");

  if (!response.ok) {
    //first opbion
    // return { isError: true, message: "Could not fetch data" };

    //second option
    // throw new Response(
    //   JSON.stringify({ message: "Could not fetch the events" }),
    //   { status: 500 }
    // );

    // third option
    return json({ message: "Could not fetch the events" }, { status: 500 });
  } else {
    const resData = await response.json();
    return resData.events;
    // return response;
  }
}

export function loader() {
  return defer({
    events: loadEvents(),
  });
}

export default EventPage;
