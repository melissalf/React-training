import {
  Link,
  redirect,
  useNavigate,
  useParams,
  useSubmit,
  useNavigation,
} from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchEvent, updateEvent, queryClient } from "../../utils/http.js";

import Modal from "../UI/Modal.jsx";
import EventForm from "./EventForm.jsx";
// import LoadingIndicator from "../UI/LoadingIndicator.jsx";
import ErrorBlock from "../UI/ErrorBlock.jsx";

export default function EditEvent() {
  const navigate = useNavigate();
  const { state } = useNavigation();
  const submit = useSubmit();
  const params = useParams();

  const { data, isError, error } = useQuery({
    queryKey: ["events", params.id],
    queryFn: ({ signal }) => fetchEvent({ id: params.id, signal }),
    staleTime: 10000, // loader already fetch the data, this to avoid that re-fetching 2 times in less than 10 seconds
  });

  // const { mutate } = useMutation({
  //   mutationFn: updateEvent,
  //   // this function will run at the same time mutate run, before the process is done and got a response
  //   onMutate: async (data) => {
  //     const newEvent = data.event;

  //     await queryClient.cancelQueries({
  //       queryKey: ["events", params.id],
  //     });
  //     const previousEvent = queryClient.getQueriesData(["events", params.id]);
  //     queryClient.setQueriesData(
  //       // manipulate the already store data without waiting for a response
  //       ["events", params.id], //key of the query to manipulate
  //       newEvent // the new data to store
  //     );

  //     return { previousEvent };
  //   },
  //   onError: (error, data, context) => {
  //     // it run if onMutation fails
  //     queryClient.setQueriesData(["events", params.id], context.previousEvent);
  //   },
  //   onSettled: () => {
  //     // will be calles when the mutation is done, regardles of the result
  //     queryClient.invalidateQueries({
  //       queryKey: ["events", params.id],
  //     });
  //   },
  // });

  function handleSubmit(formData) {
    // mutate({ id: params.id, event: formData });
    // navigate("../");
    submit(formData, { method: "PUT" });
  }

  function handleClose() {
    navigate("../");
  }

  let content;

  // if (isPending) {
  //   content = (
  //     <div className="center">
  //       <LoadingIndicator />
  //     </div>
  //   );
  // }

  if (isError) {
    content = (
      <>
        <ErrorBlock
          title="An Error has happened"
          message={error.info?.message || "Faile to Get event data."}
        />
        <div className="form-actions">
          <Link to="../" className="button">
            Okay
          </Link>
        </div>
      </>
    );
  }

  if (data) {
    content = (
      <EventForm inputData={data} onSubmit={handleSubmit}>
        {state === "submitting" ? (
          <p>Sending data...</p>
        ) : (
          <>
            <Link to="../" className="button-text">
              Cancel
            </Link>
            <button type="submit" className="button">
              Update
            </button>
          </>
        )}
      </EventForm>
    );
  }

  return <Modal onClose={handleClose}>{content}</Modal>;
}

export function loader({ params }) {
  return queryClient.fetchQuery({
    queryKey: ["events", params.id],
    queryFn: ({ signal }) => fetchEvent({ id: params.id, signal }),
  }); //fetch query data without useQuery
  //this way it fetch the data before loading the page ans wasting less time
}

export async function action({ request, params }) {
  const formData = await request.formData();
  const updatedEventData = Object.fromEntries(formData); //trans for the form data so a simple key value pair object
  await updateEvent({ id: params.id, event: updatedEventData });
  await queryClient.invalidateQueries(["events"]);
  return redirect("../");
}
