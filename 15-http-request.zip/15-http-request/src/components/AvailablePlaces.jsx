import Places from "./Places.jsx";
import Error from "./Error.jsx";
import { sortPlacesByDistance } from "../loc.js";
import { fetchAvailablePlaces } from "../http.js";
import { useFetchPlaces } from "../hooks/useFetch.js";

async function fetchSortedPlaces() {
  const places = await fetchAvailablePlaces();

  // this convert a non promise feature in a promise feature
  // this is because the function where this will be call expect a promise
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition((position) => {
      const sortedPlaces = sortPlacesByDistance(
        places,
        position.coords.latitude,
        position.coords.longitude
      );

      resolve(sortedPlaces);
    });
  });
}

export default function AvailablePlaces({ onSelectPlace }) {
  const {
    hasError,
    loading,
    placesData: availablePlaces,
  } = useFetchPlaces(fetchSortedPlaces, []);
  // const [availablePlaces, setAvailablePlaces] = useState([]);
  // const [loading, setLoading] = useState(false);
  // const [hasError, setHasError] = useState();

  // useEffect(() => {
  //   setLoading(true);
  //   async function fetchPlaces() {
  //     try {
  //       const places = await fetchAvailablePlaces();

  //       navigator.geolocation.getCurrentPosition((position) => {
  //         const sortedPlaces = sortPlacesByDistance(
  //           places,
  //           position.coords.latitude,
  //           position.coords.longitude
  //         );
  //         setAvailablePlaces(sortedPlaces);
  //         setLoading(false);
  //       });
  //     } catch (error) {
  //       setHasError({
  //         message: error.message || "Places couldn't be fetch, try again later",
  //       });
  //       setLoading(false);
  //     }
  //   }

  //   fetchPlaces();

  //   // fetch("http://localhost:3000/places")
  //   //   .then((response) => {
  //   //     return response.json();
  //   //   })
  //   //   .then((resData) => {
  //   //     setAvailablePlaces(resData.places);
  //   //   });
  // }, []);

  if (hasError) {
    return <Error title="An error has ocurred" message={hasError.message} />;
  }

  return (
    <Places
      title="Available Places"
      places={availablePlaces}
      isLoading={loading}
      loadingText="Fetching places..."
      fallbackText="No places available."
      onSelectPlace={onSelectPlace}
    />
  );
}
