import { useEffect, useState } from "react";

//custom hook
export function useFetchPlaces(fetchFn, initialValue) {
  const [loading, setLoading] = useState(false);
  const [hasError, setHasError] = useState();
  const [placesData, setPlacesData] = useState(initialValue);

  useEffect(() => {
    setLoading(true);
    async function fetchPlacesData() {
      try {
        const places = await fetchFn();
        setPlacesData(places);
      } catch (error) {
        setHasError({
          message: error.message || "Places couldn't be fetch, try again later",
        });
      }
      setLoading(false);
    }

    fetchPlacesData();
  }, [fetchFn]);

  return {
    loading,
    hasError,
    placesData,
    setPlacesData,
  };
}
